export interface LanguageConfig {
  code: string;
  name: string;
  native: string;
  script: string;
  keyboard: {
    layout: string;
    rows: string[][];
  };
  sampleText: string;
  ligatures: Array<{
    sequence: string[];
    result: string;
  }>;
  font: string;
}

const languageCache: Map<string, LanguageConfig> = new Map();

export async function loadLanguageConfig(
  languageCode: string
): Promise<LanguageConfig> {
  if (languageCache.has(languageCode)) {
    return languageCache.get(languageCode)!;
  }

  try {
    const response = await fetch(`/languages/${languageCode}.json`);
    if (!response.ok) {
      throw new Error(`Failed to load language config for ${languageCode}`);
    }

    const rawConfig: any = await response.json();
    
    // Provide defaults for optional fields
    const config: LanguageConfig = {
      code: rawConfig.code || languageCode,
      name: rawConfig.name || languageCode,
      native: rawConfig.native || rawConfig.name || languageCode,
      script: rawConfig.script || "Unknown",
      keyboard: rawConfig.keyboard || {
        layout: "qwerty",
        rows: [
          ["`", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-", "=", "Backspace"],
          ["Tab", "q", "w", "e", "r", "t", "y", "u", "i", "o", "p", "[", "]", "\\"],
          ["Caps", "a", "s", "d", "f", "g", "h", "j", "k", "l", ";", "'", "Enter"],
          ["Shift", "z", "x", "c", "v", "b", "n", "m", ",", ".", "/", "Shift"],
          ["Ctrl", "Alt", "Space", "Alt", "Ctrl"],
        ],
      },
      sampleText: rawConfig.sampleText || "Sample typing text...",
      ligatures: rawConfig.ligatures || [],
      font: rawConfig.font || "Noto Sans",
    };
    
    languageCache.set(languageCode, config);
    return config;
  } catch (error) {
    console.error(`Error loading language config for ${languageCode}:`, error);
    throw error;
  }
}

export async function loadAllLanguages(): Promise<LanguageConfig[]> {
  const languageCodes = [
    "en",
    "hi",
    "mr",
    "sa",
    "bn",
    "ta",
    "te",
    "kn",
    "ml",
    "gu",
    "pa",
    "ur",
    "ar",
    "fr",
    "ru",
    "el",
    "th",
    "ko",
    "zh",
    "ja",
  ];

  const configs = await Promise.all(
    languageCodes.map((code) => loadLanguageConfig(code))
  );

  return configs;
}
