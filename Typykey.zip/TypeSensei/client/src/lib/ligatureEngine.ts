export interface LigatureRule {
  sequence: string[];
  result: string;
}

export class LigatureEngine {
  private rules: LigatureRule[];

  constructor(rules: LigatureRule[]) {
    this.rules = rules.sort((a, b) => b.sequence.length - a.sequence.length);
  }

  applyLigatures(text: string): string {
    let result = text;
    
    for (const rule of this.rules) {
      const sequence = rule.sequence.join("");
      const regex = new RegExp(sequence, "g");
      result = result.replace(regex, rule.result);
    }

    return result;
  }

  findLigatureMatches(typedText: string): Array<{
    position: number;
    sequence: string[];
    result: string;
  }> {
    const matches: Array<{
      position: number;
      sequence: string[];
      result: string;
    }> = [];

    for (const rule of this.rules) {
      const sequence = rule.sequence.join("");
      let index = typedText.indexOf(sequence);
      
      while (index !== -1) {
        matches.push({
          position: index,
          sequence: rule.sequence,
          result: rule.result,
        });
        index = typedText.indexOf(sequence, index + 1);
      }
    }

    return matches;
  }

  validateLigature(typed: string, expected: string): boolean {
    return this.applyLigatures(typed) === expected;
  }
}
