const transliterationMap: Record<string, string> = {
  // Vowels
  a: "अ",
  aa: "आ",
  i: "इ",
  ee: "ई",
  u: "उ",
  oo: "ऊ",
  e: "ए",
  ai: "ऐ",
  o: "ओ",
  au: "औ",

  // Consonants
  k: "क",
  kh: "ख",
  g: "ग",
  gh: "घ",
  ch: "च",
  chh: "छ",
  j: "ज",
  jh: "झ",
  t: "ट",
  th: "ठ",
  d: "ड",
  dh: "ढ",
  n: "ण",
  p: "प",
  ph: "फ",
  b: "ब",
  bh: "भ",
  m: "म",
  y: "य",
  r: "र",
  l: "ल",
  v: "व",
  w: "व",
  sh: "श",
  s: "स",
  h: "ह",

  // Common words
  the: "द",
  quick: "क्विक",
  brown: "ब्राउन",
  fox: "फॉक्स",
  jumps: "जम्प्स",
  over: "ओवर",
  lazy: "लेज़ी",
  dog: "डॉग",
  practice: "प्रैक्टिस",
  makes: "मेक्स",
  perfect: "पर्फेक्ट",
  when: "व्हेन",
  learning: "लर्निंग",
  to: "टू",
  type: "टाइप",
  efficiently: "एफिशिएंटली",
  and: "एंड",
  accurately: "एक्यूरेटली",
};

export function transliterateToHindi(word: string): string {
  const lowerWord = word.toLowerCase().replace(/[.,!?;:]/g, "");

  // Check if exact word match exists
  if (transliterationMap[lowerWord]) {
    return transliterationMap[lowerWord];
  }

  // Simple phonetic transliteration
  let result = "";
  let i = 0;

  while (i < lowerWord.length) {
    let matched = false;

    // Try to match longer sequences first (3, 2, then 1 character)
    for (let len = 3; len >= 1; len--) {
      const substr = lowerWord.substring(i, i + len);
      if (transliterationMap[substr]) {
        result += transliterationMap[substr];
        i += len;
        matched = true;
        break;
      }
    }

    if (!matched) {
      i++;
    }
  }

  return result || "";
}

export function transliterateText(text: string): string[] {
  return text.split(" ").map(transliterateToHindi);
}
