import { useState, useEffect, useRef } from "react";
import { Progress } from "@/components/ui/progress";

interface TypingAreaProps {
  text: string;
  onKeyPress: (key: string, correct: boolean) => void;
  onComplete: () => void;
  hindiTransliterations: string[];
  currentLanguage: string;
}

export default function TypingArea({
  text,
  onKeyPress,
  onComplete,
  hindiTransliterations,
  currentLanguage,
}: TypingAreaProps) {
  const [typed, setTyped] = useState("");
  const [errors, setErrors] = useState<number[]>([]);
  const inputRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Backspace") {
        if (typed.length > 0) {
          setTyped((prev) => prev.slice(0, -1));
          setErrors((prev) => prev.filter((idx) => idx < typed.length - 1));
        }
        return;
      }

      if (e.key.length === 1) {
        const nextChar = text[typed.length];
        const isCorrect = e.key === nextChar;
        
        onKeyPress(e.key, isCorrect);
        
        if (!isCorrect) {
          setErrors((prev) => [...prev, typed.length]);
        }
        
        setTyped((prev) => prev + e.key);

        if (typed.length + 1 === text.length) {
          setTimeout(onComplete, 100);
        }
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [typed, text, onKeyPress, onComplete]);

  const words = text.split(" ");
  const typedWords = typed.split(" ");
  const progress = (typed.length / text.length) * 100;

  return (
    <div className="max-w-4xl mx-auto py-12" data-testid="container-typing-area">
      <div className="relative">
        <Progress value={progress} className="h-1 mb-6" data-testid="progress-typing" />
        
        <div
          ref={inputRef}
          tabIndex={0}
          className="min-h-48 p-8 rounded-lg border-2 bg-card focus:outline-none focus:ring-2 focus:ring-ring font-noto"
          data-testid="area-typing-main"
        >
          <div className="text-3xl font-medium leading-relaxed">
            {words.map((word, wordIdx) => {
              const wordStart = words.slice(0, wordIdx).join(" ").length + (wordIdx > 0 ? 1 : 0);
              const wordEnd = wordStart + word.length;
              const isCurrentWord = typed.length >= wordStart && typed.length <= wordEnd;
              const transliteration = hindiTransliterations[wordIdx] || "";

              return (
                <span
                  key={wordIdx}
                  className={`inline-block mr-2 mb-2 ${
                    isCurrentWord ? "bg-accent/30 px-1 rounded" : ""
                  }`}
                  data-testid={`word-${wordIdx}`}
                >
                  {word.split("").map((char, charIdx) => {
                    const absoluteIdx = wordStart + charIdx;
                    const isTyped = absoluteIdx < typed.length;
                    const isError = errors.includes(absoluteIdx);
                    const isCurrent = absoluteIdx === typed.length;

                    return (
                      <span
                        key={charIdx}
                        className={`
                          ${isTyped ? (isError ? "text-destructive" : "text-foreground") : "text-muted-foreground"}
                          ${isError ? "underline decoration-wavy decoration-destructive" : ""}
                          ${isCurrent ? "border-l-2 border-primary animate-pulse" : ""}
                        `}
                        data-testid={`char-${absoluteIdx}`}
                      >
                        {char}
                      </span>
                    );
                  })}
                  {transliteration && (
                    <div className="text-xs text-muted-foreground -mt-1 font-noto">
                      {transliteration}
                    </div>
                  )}
                </span>
              );
            })}
          </div>
        </div>

        <div className="mt-4 text-center text-sm text-muted-foreground" data-testid="text-hint">
          Click the typing area and start typing...
        </div>
      </div>
    </div>
  );
}
