import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Volume2, Type, Keyboard } from "lucide-react";

interface SettingsPanelProps {
  open: boolean;
  onClose: () => void;
  settings: {
    ttsEnabled: boolean;
    showTransliteration: boolean;
    fontSize: number;
    keyboardLayout: string;
    ttsSpeed: number;
  };
  onSettingsChange: (settings: any) => void;
}

export default function SettingsPanel({
  open,
  onClose,
  settings,
  onSettingsChange,
}: SettingsPanelProps) {
  const handleChange = (key: string, value: any) => {
    onSettingsChange({ ...settings, [key]: value });
  };

  return (
    <Sheet open={open} onOpenChange={onClose}>
      <SheetContent className="w-96" data-testid="panel-settings">
        <SheetHeader>
          <SheetTitle>Settings</SheetTitle>
        </SheetHeader>

        <div className="mt-6 space-y-6">
          <div className="space-y-4">
            <h3 className="text-sm font-medium flex items-center gap-2">
              <Volume2 className="h-4 w-4" />
              Audio
            </h3>

            <div className="flex items-center justify-between">
              <Label htmlFor="tts-enabled" className="text-sm">
                Text-to-Speech
              </Label>
              <Switch
                id="tts-enabled"
                checked={settings.ttsEnabled}
                onCheckedChange={(checked) => handleChange("ttsEnabled", checked)}
                data-testid="switch-tts"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="tts-speed" className="text-sm">
                TTS Speed
              </Label>
              <Slider
                id="tts-speed"
                min={0.5}
                max={2}
                step={0.1}
                value={[settings.ttsSpeed]}
                onValueChange={([value]) => handleChange("ttsSpeed", value)}
                disabled={!settings.ttsEnabled}
                data-testid="slider-tts-speed"
              />
              <div className="text-xs text-muted-foreground text-right">
                {settings.ttsSpeed.toFixed(1)}x
              </div>
            </div>

            <Button
              variant="outline"
              size="sm"
              disabled={!settings.ttsEnabled}
              onClick={() => {
                const utterance = new SpeechSynthesisUtterance("Test voice");
                utterance.rate = settings.ttsSpeed;
                utterance.lang = "hi-IN";
                window.speechSynthesis.speak(utterance);
              }}
              data-testid="button-test-voice"
            >
              Test Voice
            </Button>
          </div>

          <div className="space-y-4 border-t pt-4">
            <h3 className="text-sm font-medium flex items-center gap-2">
              <Type className="h-4 w-4" />
              Appearance
            </h3>

            <div className="flex items-center justify-between">
              <Label htmlFor="show-transliteration" className="text-sm">
                Show Hindi Transliteration
              </Label>
              <Switch
                id="show-transliteration"
                checked={settings.showTransliteration}
                onCheckedChange={(checked) => handleChange("showTransliteration", checked)}
                data-testid="switch-transliteration"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="font-size" className="text-sm">
                Font Size
              </Label>
              <Slider
                id="font-size"
                min={14}
                max={36}
                step={2}
                value={[settings.fontSize]}
                onValueChange={([value]) => handleChange("fontSize", value)}
                data-testid="slider-font-size"
              />
              <div className="text-xs text-muted-foreground text-right">
                {settings.fontSize}px
              </div>
            </div>
          </div>

          <div className="space-y-4 border-t pt-4">
            <h3 className="text-sm font-medium flex items-center gap-2">
              <Keyboard className="h-4 w-4" />
              Keyboard
            </h3>

            <div className="space-y-2">
              <Label htmlFor="keyboard-layout" className="text-sm">
                Layout
              </Label>
              <select
                id="keyboard-layout"
                value={settings.keyboardLayout}
                onChange={(e) => handleChange("keyboardLayout", e.target.value)}
                className="w-full h-9 px-3 rounded-md border bg-background text-sm"
                data-testid="select-keyboard-layout"
              >
                <option value="qwerty">QWERTY</option>
                <option value="azerty">AZERTY</option>
                <option value="dvorak">Dvorak</option>
                <option value="inscript">Inscript (Hindi)</option>
              </select>
            </div>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
