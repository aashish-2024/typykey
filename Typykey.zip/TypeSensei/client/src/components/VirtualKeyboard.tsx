import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { loadLanguageConfig } from "@/lib/languageLoader";

interface VirtualKeyboardProps {
  layout: string;
  language: string;
}

const qwertyLayout = [
  ["`", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-", "=", "Backspace"],
  ["Tab", "q", "w", "e", "r", "t", "y", "u", "i", "o", "p", "[", "]", "\\"],
  ["Caps", "a", "s", "d", "f", "g", "h", "j", "k", "l", ";", "'", "Enter"],
  ["Shift", "z", "x", "c", "v", "b", "n", "m", ",", ".", "/", "Shift"],
  ["Ctrl", "Alt", "Space", "Alt", "Ctrl"],
];

export default function VirtualKeyboard({ layout, language }: VirtualKeyboardProps) {
  const [pressedKeys, setPressedKeys] = useState<Set<string>>(new Set());
  const [keyboardLayout, setKeyboardLayout] = useState<string[][]>(qwertyLayout);

  useEffect(() => {
    const loadLayout = async () => {
      try {
        const config = await loadLanguageConfig(language);
        if (config.keyboard?.rows) {
          setKeyboardLayout(config.keyboard.rows);
        } else {
          setKeyboardLayout(qwertyLayout);
        }
      } catch (error) {
        console.error("Failed to load keyboard layout:", error);
        setKeyboardLayout(qwertyLayout);
      }
    };

    loadLayout();
  }, [language]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      setPressedKeys((prev) => {
        const next = new Set(prev);
        next.add(e.key.toLowerCase());
        return next;
      });
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      setPressedKeys((prev) => {
        const next = new Set(prev);
        next.delete(e.key.toLowerCase());
        return next;
      });
    };

    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("keyup", handleKeyUp);

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("keyup", handleKeyUp);
    };
  }, []);

  const getKeyWidth = (key: string) => {
    if (key === "Backspace") return "w-20";
    if (key === "Tab") return "w-16";
    if (key === "Caps") return "w-20";
    if (key === "Enter") return "w-24";
    if (key === "Shift") return "w-24";
    if (key === "Space") return "flex-1";
    if (key === "Ctrl" || key === "Alt") return "w-16";
    return "w-12";
  };

  return (
    <div className="max-w-5xl mx-auto p-6" data-testid="container-keyboard">
      <Card className="p-4">
        <div className="space-y-1">
          {keyboardLayout.map((row, rowIdx) => (
            <div key={rowIdx} className="flex gap-1 justify-center">
              {row.map((key, keyIdx) => {
                const isPressed = pressedKeys.has(key.toLowerCase()) || 
                                (key === " " && pressedKeys.has("space")) ||
                                (key === "Backspace" && pressedKeys.has("backspace")) ||
                                (key === "Enter" && pressedKeys.has("enter")) ||
                                (key === "Tab" && pressedKeys.has("tab")) ||
                                (key === "Shift" && pressedKeys.has("shift")) ||
                                (key === "Ctrl" && pressedKeys.has("control")) ||
                                (key === "Alt" && pressedKeys.has("alt"));

                return (
                  <div
                    key={keyIdx}
                    className={`
                      ${getKeyWidth(key)}
                      min-h-12 
                      flex items-center justify-center 
                      rounded-md 
                      border-2
                      text-sm font-medium
                      transition-all duration-75
                      ${
                        isPressed
                          ? "bg-primary text-primary-foreground border-primary scale-95"
                          : "bg-background border-border"
                      }
                    `}
                    data-testid={`key-${key}`}
                  >
                    <span className="font-noto">{key === "Space" ? "" : key}</span>
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
