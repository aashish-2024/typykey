import { Card } from "@/components/ui/card";
import { Clock, Target, AlertCircle, TrendingUp } from "lucide-react";

interface StatsPanelProps {
  wpm: number;
  accuracy: number;
  errors: number;
  timeElapsed: number;
  keyErrors?: number;
  ligatureErrors?: number;
}

export default function StatsPanel({
  wpm,
  accuracy,
  errors,
  timeElapsed,
  keyErrors = 0,
  ligatureErrors = 0,
}: StatsPanelProps) {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const stats = [
    {
      label: "WPM",
      value: wpm,
      icon: TrendingUp,
      color: "text-chart-1",
      testId: "stat-wpm",
    },
    {
      label: "Accuracy",
      value: `${accuracy}%`,
      icon: Target,
      color: "text-chart-2",
      testId: "stat-accuracy",
    },
    {
      label: "Errors",
      value: errors,
      icon: AlertCircle,
      color: "text-destructive",
      testId: "stat-errors",
    },
    {
      label: "Time",
      value: formatTime(timeElapsed),
      icon: Clock,
      color: "text-muted-foreground",
      testId: "stat-time",
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-8 py-6" data-testid="container-stats">
      <div className="grid grid-cols-4 gap-4">
        {stats.map((stat) => (
          <Card key={stat.label} className="p-4" data-testid={stat.testId}>
            <div className="flex items-start justify-between">
              <div>
                <div className="text-sm uppercase tracking-wide text-muted-foreground mb-1">
                  {stat.label}
                </div>
                <div className="text-3xl font-semibold" data-testid={`${stat.testId}-value`}>
                  {stat.value}
                </div>
              </div>
              <stat.icon className={`h-5 w-5 ${stat.color}`} />
            </div>
          </Card>
        ))}
      </div>

      {(keyErrors > 0 || ligatureErrors > 0) && (
        <div className="mt-4 grid grid-cols-2 gap-4">
          <Card className="p-4">
            <div className="text-sm text-muted-foreground">Key Errors</div>
            <div className="text-2xl font-semibold mt-1" data-testid="stat-key-errors">
              {keyErrors}
            </div>
          </Card>
          <Card className="p-4">
            <div className="text-sm text-muted-foreground">Ligature Errors</div>
            <div className="text-2xl font-semibold mt-1" data-testid="stat-ligature-errors">
              {ligatureErrors}
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}
