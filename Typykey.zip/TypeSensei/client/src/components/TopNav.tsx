import { Settings, Moon, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";

interface TopNavProps {
  onSettingsClick: () => void;
  currentLanguage: string;
  onLanguageChange: (lang: string) => void;
  wpm: number;
  accuracy: number;
}

const languages = [
  { code: "en", name: "English", native: "English" },
  { code: "hi", name: "Hindi", native: "हिन्दी" },
  { code: "mr", name: "Marathi", native: "मराठी" },
  { code: "sa", name: "Sanskrit", native: "संस्कृत" },
  { code: "bn", name: "Bengali", native: "বাংলা" },
  { code: "ta", name: "Tamil", native: "தமிழ்" },
  { code: "te", name: "Telugu", native: "తెలుగు" },
  { code: "kn", name: "Kannada", native: "ಕನ್ನಡ" },
  { code: "ml", name: "Malayalam", native: "മലയാളം" },
  { code: "gu", name: "Gujarati", native: "ગુજરાતી" },
  { code: "pa", name: "Punjabi", native: "ਪੰਜਾਬੀ" },
  { code: "ur", name: "Urdu", native: "اردو" },
  { code: "ar", name: "Arabic", native: "العربية" },
  { code: "fr", name: "French", native: "Français" },
  { code: "ru", name: "Russian", native: "Русский" },
  { code: "el", name: "Greek", native: "Ελληνικά" },
  { code: "th", name: "Thai", native: "ไทย" },
  { code: "ko", name: "Korean", native: "한국어" },
  { code: "zh", name: "Chinese", native: "中文" },
  { code: "ja", name: "Japanese", native: "日本語" },
];

export default function TopNav({
  onSettingsClick,
  currentLanguage,
  onLanguageChange,
  wpm,
  accuracy,
}: TopNavProps) {
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    const isDark = document.documentElement.classList.contains("dark");
    setDarkMode(isDark);
  }, []);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    document.documentElement.classList.toggle("dark");
  };

  return (
    <nav className="h-16 border-b flex items-center justify-between px-8" data-testid="nav-top">
      <div className="flex items-center gap-3">
        <h1 className="text-xl font-semibold" data-testid="text-app-title">
          TypeMaster
        </h1>
      </div>

      <div className="flex items-center gap-4">
        <select
          value={currentLanguage}
          onChange={(e) => onLanguageChange(e.target.value)}
          className="w-56 h-9 px-3 rounded-md border bg-background text-sm hover-elevate font-noto"
          data-testid="select-language"
        >
          {languages.map((lang) => (
            <option key={lang.code} value={lang.code}>
              {lang.name} ({lang.native})
            </option>
          ))}
        </select>

        <div className="flex items-center gap-4 text-sm">
          <div className="flex items-center gap-2" data-testid="stat-wpm-nav">
            <span className="text-muted-foreground">WPM:</span>
            <span className="font-semibold">{wpm}</span>
          </div>
          <div className="flex items-center gap-2" data-testid="stat-accuracy-nav">
            <span className="text-muted-foreground">Accuracy:</span>
            <span className="font-semibold">{accuracy}%</span>
          </div>
        </div>

        <Button
          size="icon"
          variant="ghost"
          onClick={toggleDarkMode}
          data-testid="button-theme-toggle"
        >
          {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
        </Button>

        <Button
          size="icon"
          variant="ghost"
          onClick={onSettingsClick}
          data-testid="button-settings"
        >
          <Settings className="h-5 w-5" />
        </Button>
      </div>
    </nav>
  );
}
