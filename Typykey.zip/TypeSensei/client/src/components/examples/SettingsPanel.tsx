import { useState } from "react";
import SettingsPanel from "../SettingsPanel";
import { Button } from "@/components/ui/button";

export default function SettingsPanelExample() {
  const [open, setOpen] = useState(false);
  const [settings, setSettings] = useState({
    ttsEnabled: true,
    showTransliteration: true,
    fontSize: 30,
    keyboardLayout: "qwerty",
    ttsSpeed: 1.0,
  });

  return (
    <div className="p-8">
      <Button onClick={() => setOpen(true)} data-testid="button-open-settings">
        Open Settings
      </Button>
      <SettingsPanel
        open={open}
        onClose={() => setOpen(false)}
        settings={settings}
        onSettingsChange={setSettings}
      />
    </div>
  );
}
