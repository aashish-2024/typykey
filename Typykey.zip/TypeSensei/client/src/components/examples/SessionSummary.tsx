import { useState } from "react";
import SessionSummary from "../SessionSummary";
import { Button } from "@/components/ui/button";

export default function SessionSummaryExample() {
  const [open, setOpen] = useState(true);

  return (
    <div className="p-8">
      <Button onClick={() => setOpen(true)} data-testid="button-open-summary">
        Show Session Summary
      </Button>
      <SessionSummary
        open={open}
        onClose={() => setOpen(false)}
        wpm={52}
        accuracy={96}
        errors={6}
        keyErrors={4}
        ligatureErrors={2}
        timeElapsed={180}
        onRetry={() => console.log("Retry clicked")}
        onNewSession={() => console.log("New session clicked")}
      />
    </div>
  );
}
