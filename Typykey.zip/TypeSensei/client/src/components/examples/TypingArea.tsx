import TypingArea from "../TypingArea";

export default function TypingAreaExample() {
  const sampleText = "The quick brown fox jumps over the lazy dog";
  const sampleTransliterations = [
    "द",
    "क्विक",
    "ब्राउन",
    "फॉक्स",
    "जम्प्स",
    "ओवर",
    "द",
    "लेज़ी",
    "डॉग",
  ];

  return (
    <TypingArea
      text={sampleText}
      onKeyPress={(key, correct) => console.log(`Pressed: ${key}, Correct: ${correct}`)}
      onComplete={() => console.log("Typing complete!")}
      hindiTransliterations={sampleTransliterations}
      currentLanguage="en"
    />
  );
}
