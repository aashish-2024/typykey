import TopNav from "../TopNav";

export default function TopNavExample() {
  return (
    <TopNav
      onSettingsClick={() => console.log("Settings clicked")}
      currentLanguage="hi"
      onLanguageChange={(lang) => console.log("Language changed to:", lang)}
      wpm={45}
      accuracy={94}
    />
  );
}
