import ErrorFeedback from "../ErrorFeedback";

export default function ErrorFeedbackExample() {
  const sampleErrors = [
    { id: 1, incorrect: "teh", correct: "the", type: "key" as const },
    { id: 2, incorrect: "qiuck", correct: "quick", type: "key" as const },
    { id: 3, incorrect: "क्", correct: "क्ष", type: "ligature" as const },
    { id: 4, incorrect: "ज्न", correct: "ज्ञ", type: "ligature" as const },
    { id: 5, incorrect: "recieve", correct: "receive", type: "key" as const },
  ];

  return <ErrorFeedback errors={sampleErrors} />;
}
