import VirtualKeyboard from "../VirtualKeyboard";

export default function VirtualKeyboardExample() {
  return (
    <div className="p-8 bg-background">
      <div className="mb-4 text-center text-sm text-muted-foreground">
        Press keys on your keyboard to see them highlight
      </div>
      <VirtualKeyboard layout="qwerty" language="en" />
    </div>
  );
}
