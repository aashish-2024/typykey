import StatsPanel from "../StatsPanel";

export default function StatsPanelExample() {
  return (
    <StatsPanel
      wpm={45}
      accuracy={94}
      errors={8}
      timeElapsed={125}
      keyErrors={5}
      ligatureErrors={3}
    />
  );
}
