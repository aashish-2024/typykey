import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Trophy, RotateCcw, Play } from "lucide-react";

interface SessionSummaryProps {
  open: boolean;
  onClose: () => void;
  wpm: number;
  accuracy: number;
  errors: number;
  keyErrors: number;
  ligatureErrors: number;
  timeElapsed: number;
  onRetry: () => void;
  onNewSession: () => void;
}

export default function SessionSummary({
  open,
  onClose,
  wpm,
  accuracy,
  errors,
  keyErrors,
  ligatureErrors,
  timeElapsed,
  onRetry,
  onNewSession,
}: SessionSummaryProps) {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const stats = [
    { label: "Words Per Minute", value: wpm, testId: "summary-wpm" },
    { label: "Accuracy", value: `${accuracy}%`, testId: "summary-accuracy" },
    { label: "Total Errors", value: errors, testId: "summary-errors" },
    { label: "Time Elapsed", value: formatTime(timeElapsed), testId: "summary-time" },
    { label: "Key Errors", value: keyErrors, testId: "summary-key-errors" },
    { label: "Ligature Errors", value: ligatureErrors, testId: "summary-ligature-errors" },
  ];

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl" data-testid="modal-session-summary">
        <DialogHeader>
          <div className="flex items-center gap-3">
            <Trophy className="h-8 w-8 text-chart-1" />
            <DialogTitle className="text-2xl">Session Complete!</DialogTitle>
          </div>
        </DialogHeader>

        <div className="mt-6">
          <div className="grid grid-cols-2 gap-4">
            {stats.map((stat) => (
              <Card key={stat.label} className="p-4" data-testid={stat.testId}>
                <div className="text-sm text-muted-foreground mb-2">{stat.label}</div>
                <div className="text-3xl font-semibold">{stat.value}</div>
              </Card>
            ))}
          </div>

          <div className="mt-6 p-4 rounded-lg bg-muted/50">
            <h3 className="font-medium mb-2">Error Breakdown</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Missed Keys</span>
                <span className="font-medium">{keyErrors}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Ligature Mistakes</span>
                <span className="font-medium">{ligatureErrors}</span>
              </div>
              <div className="flex justify-between border-t pt-2 mt-2">
                <span className="text-muted-foreground">Total</span>
                <span className="font-semibold">{errors}</span>
              </div>
            </div>
          </div>

          <div className="mt-6 flex gap-3">
            <Button onClick={onRetry} variant="outline" className="flex-1" data-testid="button-retry">
              <RotateCcw className="h-4 w-4 mr-2" />
              Retry
            </Button>
            <Button onClick={onNewSession} className="flex-1" data-testid="button-new-session">
              <Play className="h-4 w-4 mr-2" />
              New Session
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
