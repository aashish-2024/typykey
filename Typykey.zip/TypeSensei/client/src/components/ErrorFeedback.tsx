import { Card } from "@/components/ui/card";
import { ArrowRight, AlertTriangle } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface ErrorItem {
  id: number;
  incorrect: string;
  correct: string;
  type: "key" | "ligature";
}

interface ErrorFeedbackProps {
  errors: ErrorItem[];
}

export default function ErrorFeedback({ errors }: ErrorFeedbackProps) {
  if (errors.length === 0) {
    return null;
  }

  const recentErrors = errors.slice(-5);

  return (
    <div className="max-w-4xl mx-auto px-8 py-4" data-testid="container-error-feedback">
      <Card className="p-4">
        <div className="flex items-center gap-2 mb-3">
          <AlertTriangle className="h-4 w-4 text-destructive" />
          <h3 className="font-medium text-sm">Recent Errors</h3>
        </div>
        
        <div className="space-y-2">
          {recentErrors.map((error) => (
            <div
              key={error.id}
              className="flex items-center gap-3 p-2 rounded-md bg-muted/50"
              data-testid={`error-item-${error.id}`}
            >
              <Badge variant={error.type === "ligature" ? "default" : "secondary"} className="text-xs">
                {error.type === "ligature" ? "Ligature" : "Key"}
              </Badge>
              
              <div className="flex items-center gap-2 flex-1 font-mono">
                <span className="text-destructive font-medium" data-testid={`error-incorrect-${error.id}`}>
                  {error.incorrect}
                </span>
                <ArrowRight className="h-3 w-3 text-muted-foreground" />
                <span className="text-chart-2 font-medium" data-testid={`error-correct-${error.id}`}>
                  {error.correct}
                </span>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
