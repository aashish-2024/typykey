import { useState, useEffect, useCallback } from "react";
import TopNav from "@/components/TopNav";
import TypingArea from "@/components/TypingArea";
import VirtualKeyboard from "@/components/VirtualKeyboard";
import StatsPanel from "@/components/StatsPanel";
import SessionSummary from "@/components/SessionSummary";
import ErrorFeedback from "@/components/ErrorFeedback";
import SettingsPanel from "@/components/SettingsPanel";
import { Volume2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { loadLanguageConfig, type LanguageConfig } from "@/lib/languageLoader";
import { LigatureEngine } from "@/lib/ligatureEngine";
import { transliterateText } from "@/lib/hindiTransliteration";
import { apiRequest } from "@/lib/queryClient";

export default function Home() {
  const [currentLanguage, setCurrentLanguage] = useState("en");
  const [languageConfig, setLanguageConfig] = useState<LanguageConfig | null>(null);
  const [ligatureEngine, setLigatureEngine] = useState<LigatureEngine | null>(null);
  const [currentText, setCurrentText] = useState("");
  const [wpm, setWpm] = useState(0);
  const [accuracy, setAccuracy] = useState(100);
  const [errors, setErrors] = useState(0);
  const [keyErrors, setKeyErrors] = useState(0);
  const [ligatureErrors, setLigatureErrors] = useState(0);
  const [timeElapsed, setTimeElapsed] = useState(0);
  const [sessionActive, setSessionActive] = useState(false);
  const [showSummary, setShowSummary] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [errorList, setErrorList] = useState<any[]>([]);
  const [totalCharsTyped, setTotalCharsTyped] = useState(0);
  const [settings, setSettings] = useState({
    ttsEnabled: true,
    showTransliteration: true,
    fontSize: 30,
    keyboardLayout: "qwerty",
    ttsSpeed: 1.0,
  });
  const [hindiTransliterations, setHindiTransliterations] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  // Load language configuration
  useEffect(() => {
    const loadConfig = async () => {
      try {
        setLoading(true);
        const config = await loadLanguageConfig(currentLanguage);
        setLanguageConfig(config);
        setCurrentText(config.sampleText);
        setLigatureEngine(new LigatureEngine(config.ligatures || []));
        setLoading(false);
      } catch (error) {
        console.error("Failed to load language config:", error);
        setLoading(false);
      }
    };

    loadConfig();
  }, [currentLanguage]);

  // Generate Hindi transliterations
  useEffect(() => {
    if (currentText && settings.showTransliteration) {
      const transliterations = transliterateText(currentText);
      setHindiTransliterations(transliterations);
    } else {
      setHindiTransliterations([]);
    }
  }, [currentText, settings.showTransliteration]);

  // Session timer
  useEffect(() => {
    if (sessionActive) {
      const interval = setInterval(() => {
        setTimeElapsed((prev) => prev + 1);
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [sessionActive]);

  const handleKeyPress = useCallback(
    (key: string, correct: boolean) => {
      if (!sessionActive) {
        setSessionActive(true);
      }

      // Increment total characters typed
      const newTotalChars = totalCharsTyped + 1;
      setTotalCharsTyped(newTotalChars);

      // Track errors
      let newErrors = errors;
      if (!correct) {
        newErrors = errors + 1;
        setErrors(newErrors);
        setKeyErrors((prev) => prev + 1);
        setErrorList((prev) => [
          ...prev,
          {
            id: Date.now(),
            incorrect: key,
            correct: "?",
            type: "key",
          },
        ]);
      }

      // Calculate accuracy with updated values
      const newAccuracy = newTotalChars > 0
        ? Math.round(((newTotalChars - newErrors) / newTotalChars) * 100)
        : 100;
      setAccuracy(newAccuracy);

      // Calculate WPM with updated values (guard against divide by zero)
      if (timeElapsed > 0) {
        const minutes = timeElapsed / 60;
        const words = newTotalChars / 5; // Standard: 5 characters = 1 word
        const newWpm = Math.round(words / minutes);
        setWpm(newWpm);
      }

      if (settings.ttsEnabled && settings.showTransliteration) {
        const wordIndex = Math.floor(Math.random() * hindiTransliterations.length);
        const transliteration = hindiTransliterations[wordIndex];
        if (transliteration && Math.random() > 0.9) {
          const utterance = new SpeechSynthesisUtterance(transliteration);
          utterance.lang = "hi-IN";
          utterance.rate = settings.ttsSpeed;
          window.speechSynthesis.speak(utterance);
        }
      }
    },
    [sessionActive, errors, totalCharsTyped, timeElapsed, settings, hindiTransliterations]
  );

  const handleComplete = async () => {
    setSessionActive(false);
    
    // Save results to backend
    try {
      await apiRequest("POST", "/api/typing-results", {
        language: currentLanguage,
        wpm,
        accuracy,
        errors,
        keyErrors,
        ligatureErrors,
        timeElapsed,
        textLength: currentText.length,
        errorDetails: errorList,
      });
    } catch (error) {
      console.error("Failed to save typing results:", error);
    }

    setShowSummary(true);
  };

  const handleRetry = () => {
    resetSession();
    setShowSummary(false);
  };

  const handleNewSession = () => {
    resetSession();
    setShowSummary(false);
  };

  const resetSession = () => {
    setWpm(0);
    setAccuracy(100);
    setErrors(0);
    setKeyErrors(0);
    setLigatureErrors(0);
    setTimeElapsed(0);
    setSessionActive(false);
    setErrorList([]);
    setTotalCharsTyped(0);
  };

  const handleLanguageChange = async (lang: string) => {
    setCurrentLanguage(lang);
    resetSession();
  };

  const speakTransliteration = () => {
    if (settings.ttsEnabled) {
      const sampleText = hindiTransliterations.filter(Boolean).join(" ");
      if (sampleText) {
        const utterance = new SpeechSynthesisUtterance(sampleText);
        utterance.lang = "hi-IN";
        utterance.rate = settings.ttsSpeed;
        window.speechSynthesis.speak(utterance);
      }
    }
  };

  if (loading || !languageConfig) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="text-lg font-medium">Loading language configuration...</div>
          <div className="text-sm text-muted-foreground mt-2">
            Preparing {currentLanguage.toUpperCase()} keyboard layout
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <TopNav
        onSettingsClick={() => setShowSettings(true)}
        currentLanguage={currentLanguage}
        onLanguageChange={handleLanguageChange}
        wpm={wpm}
        accuracy={accuracy}
      />

      <main className="flex-1 overflow-auto">
        <StatsPanel
          wpm={wpm}
          accuracy={accuracy}
          errors={errors}
          timeElapsed={timeElapsed}
          keyErrors={keyErrors}
          ligatureErrors={ligatureErrors}
        />

        {settings.showTransliteration && hindiTransliterations.some(Boolean) && (
          <div className="max-w-4xl mx-auto px-8 mb-4">
            <Button
              variant="outline"
              size="sm"
              onClick={speakTransliteration}
              disabled={!settings.ttsEnabled}
              data-testid="button-speak-transliteration"
            >
              <Volume2 className="h-4 w-4 mr-2" />
              Speak Hindi Transliteration
            </Button>
          </div>
        )}

        <TypingArea
          text={currentText}
          onKeyPress={handleKeyPress}
          onComplete={handleComplete}
          hindiTransliterations={settings.showTransliteration ? hindiTransliterations : []}
          currentLanguage={currentLanguage}
        />

        <ErrorFeedback errors={errorList} />

        <VirtualKeyboard layout={settings.keyboardLayout} language={currentLanguage} />
      </main>

      <SessionSummary
        open={showSummary}
        onClose={() => setShowSummary(false)}
        wpm={wpm}
        accuracy={accuracy}
        errors={errors}
        keyErrors={keyErrors}
        ligatureErrors={ligatureErrors}
        timeElapsed={timeElapsed}
        onRetry={handleRetry}
        onNewSession={handleNewSession}
      />

      <SettingsPanel
        open={showSettings}
        onClose={() => setShowSettings(false)}
        settings={settings}
        onSettingsChange={setSettings}
      />
    </div>
  );
}
